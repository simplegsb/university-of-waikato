
import java.io.*;
import java.lang.Boolean;

public class FileData 
{
    String query_word_;
    int array_len_;
    char array_[];
    

    public FileData()
    {
	query_word_ = null;
	array_len_  = 0;
	array_      = null;
    }

    public void readFileData(String file_in)
    {
	try {
	    FileInputStream fis = new FileInputStream(file_in);
	    InputStreamReader isr = new InputStreamReader(fis);
	    BufferedReader br = new BufferedReader(isr);

	    query_word_ = br.readLine();

	    String array_len_str = br.readLine();
	    array_len_ = Integer.parseInt(array_len_str);

	    array_ = new char[array_len_];
	    br.read(array_,0,array_len_);

	    br.close();
	}
	catch (Exception e) {
	    System.err.println("Error encountered reading file '"+file_in+"'");
	    System.exit(3);
	}


    }

    
    public void processFileData()
    {
	int query_len  = query_word_.length();
	int search_len = array_len_ - query_len + 1;

	String array_str = new String(array_);

	boolean found_match = false;

	for (int i=0; i<search_len; i++) {

	    String excerpt_str = array_str.substring(i,i+query_len);
	    
	    if (query_word_.matches(excerpt_str)) {
		System.out.println("Match found at position: " + i);
		found_match = true;
	    }
	}
	
	if (!found_match) {
	    System.err.println("No matches!\n");
	}
    }

}
