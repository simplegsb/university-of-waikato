
public class StrPos
{

    static protected void printUsage()
    {
	System.err.println("strpos [-h] filename");
    }

    static protected String parseArgs(String args[])
    {
	for (int i=0; i<args.length; i++) {
	    if (args[i].startsWith("-h")) {
		printUsage();
		System.exit(1);
	    }
	}

	if (args.length!=1) {
	    printUsage();
	    System.exit(1);
	}
	
	return args[0];
    }



    static public void main(String args[])
    {

	String in_file = parseArgs(args);
	
	FileData file_data = new FileData();
	
	file_data.readFileData(in_file);
	file_data.processFileData();
    }


}
